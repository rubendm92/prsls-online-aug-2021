module.exports = {  
  testEnvironment: 'node',
  testMatch: ['**/test_cases/**/*']
}